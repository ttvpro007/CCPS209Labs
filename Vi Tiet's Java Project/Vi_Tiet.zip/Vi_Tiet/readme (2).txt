Total number of completed labs: 18

Labs that pass the teseter in less than 10 secs:
1. Lab 0(A) - P2J1
2. Lab 0(B) - P2J2
3. Lab 0(C) - P2J3
4. Lab 0(D) - P2J4
5. Lab 1 - Polynomial I: Basics
6. Lab 2 - Polynomial II: Arithmethic
7. Lab 3 - Polynomial III: Comparisons
8. Lab 4 - Extending An Existing Class
9. Lab 6 - Text Files I: Word Count
10. Lab 7 - Text Files II: Tail
11. Lab 10 - Computation Streams
12. Lab 11 - And You Will Find Me, Prime After Prime

Labs completed with swing components
13. Lab 5 - It's All In Your Head
14. Lab 8 - Concurrency In Animation
15. Lab 9 - Lissajous Curves
16. Lab 12 - The Second Hand Unwinds
17. Lab 13 - Recursive Mondrian Art
18. Lab 14 - H-Tree Fractal

Utility Classes
- Utils
- GraphicsUtils
- Vector2
- IFactory
- JLabelFactory
- JSliderFactory
- JTextFieldFactory
- JButtonFactory
- JPanelExtends
- JFrameExtends
- IAnimation

Example and Playground Classes
- SpaceFiller
- Turtle
- LSystem
- LSystemMain
- LSystemPanel

Error
- P2J2Test.testRemoveDuplicates() failed in BlueJ but passed in Eclipse