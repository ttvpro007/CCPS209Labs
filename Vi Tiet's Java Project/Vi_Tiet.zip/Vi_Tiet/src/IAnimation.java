package src;

import java.awt.Graphics2D;

public interface IAnimation {
	
	void update(Graphics2D g2D, double t);
}
