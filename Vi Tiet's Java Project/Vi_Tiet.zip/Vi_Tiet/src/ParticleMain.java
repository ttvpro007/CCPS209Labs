package src;

public class ParticleMain {

	public static void main(String[] args) {
	
		ParticleField.display(2000, PANEL_SIZE, PANEL_SIZE);
	}
	
	private static final int PANEL_SIZE = 800;
}