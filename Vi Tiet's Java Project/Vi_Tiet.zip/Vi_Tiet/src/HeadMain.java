package src;

public class HeadMain {
    
	public static void main(String[] args) {

        Head.display(TOTAL_HEADS, Head.DISPLAY_MODE.HORIZONTAL);
    }
	
    private static final int TOTAL_HEADS = 4;
}