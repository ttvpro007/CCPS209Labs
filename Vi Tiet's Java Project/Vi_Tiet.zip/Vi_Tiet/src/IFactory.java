package src;


public interface IFactory<C> {

	public C create();
}
